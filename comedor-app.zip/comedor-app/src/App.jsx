import { useState, useEffect, useRef } from "react";
import {
  ShoppingCart, Plus, Minus, X, LogOut, Settings, Trash2,
  Upload, Eye, EyeOff, ChevronRight, ChevronDown, Package,
  Clock, Phone, MapPin, Star, Bell, RefreshCw, Save, Check,
  Mail, Edit3, Menu as MenuIcon, Users, DollarSign, TrendingUp
} from "lucide-react";

/* ════════════════════════════════════════════
   STORAGE HELPERS
════════════════════════════════════════════ */
const db = {
  get: async (k) => {
    try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : null; }
    catch { return null; }
  },
  set: async (k, v) => {
    try { localStorage.setItem(k, JSON.stringify(v)); return true; }
    catch { return false; }
  }
};

/* ════════════════════════════════════════════
   CONSTANTS
════════════════════════════════════════════ */
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const fmt$ = (n) => `$${parseFloat(n || 0).toFixed(2)}`;
const nowDate = () => new Date().toLocaleDateString('es-SV', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

const DELIVERY_TIMES = [
  '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM',
  '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM',
  '3:00 PM', '4:00 PM', '5:00 PM'
];

const CAT_LABELS = {
  platos: '🍽️ Platos del Día',
  extras: '✨ Extras',
  ensaladas: '🥗 Ensaladas',
  bebidas: '🥤 Bebidas',
  postres: '🍮 Postres'
};

const STATUS_INFO = {
  pendiente:  { label: '⏳ Pendiente',   bg: '#FFF3CD', color: '#856404' },
  preparando: { label: '👨‍🍳 Preparando', bg: '#D1ECF1', color: '#0C5460' },
  enviado:    { label: '🚗 En Camino',   bg: '#D4EDDA', color: '#155724' },
  entregado:  { label: '✅ Entregado',   bg: '#CCE5FF', color: '#004085' },
};
const STATUS_NEXT = { pendiente: 'preparando', preparando: 'enviado', enviado: 'entregado' };

const FOOD_EMOJIS = ['🍽️','🥣','🥩','🍗','🍖','🐷','🐮','🐟','🦐','🥚','🧀','🥑','🥗','🥒','🍅','🌽','🥤','🍮','🍞','🫔','🌶️','🍋','🥜','🫕'];

const DEF_CONFIG = {
  name: 'El Buen Sabor',
  phone: '7461-0306',
  address: 'San Salvador, El Salvador',
  logo: null,
  desc: 'Comida casera salvadoreña con sabor de hogar 🇸🇻'
};

const DEF_MENU = {
  date: '',
  active: true,
  message: '¡LINDO DÍA BENDICIONES! 🌈',
  items: [
    { id: 'm1', cat: 'platos', name: 'Sopa de Gallina', emoji: '🥣', price: 3.75 },
    { id: 'm2', cat: 'platos', name: 'Lonja Empanizada', emoji: '🍖', price: 3.00 },
    { id: 'm3', cat: 'platos', name: 'Pollo en Salsa Jalapeño', emoji: '🍗', price: 3.00 },
    { id: 'm4', cat: 'platos', name: 'Pechuga Jalapeño', emoji: '🍗', price: 3.25 },
    { id: 'm5', cat: 'platos', name: 'Albóndigas', emoji: '🥩', price: 3.00 },
    { id: 'm6', cat: 'extras', name: 'Queso Duro', emoji: '🧀', price: 0.35 },
    { id: 'm7', cat: 'extras', name: 'Queso Fresco', emoji: '🧀', price: 0.35 },
    { id: 'm8', cat: 'extras', name: 'Aguacate', emoji: '🥑', price: 0.40 },
    { id: 'm9', cat: 'ensaladas', name: 'Ensalada Fresca', emoji: '🥗', price: 0 },
    { id: 'm10', cat: 'ensaladas', name: 'Ensalada de Pepino', emoji: '🥒', price: 0 },
  ]
};

/* ════════════════════════════════════════════
   GLOBAL STYLES
════════════════════════════════════════════ */
const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Pacifico&family=Nunito:wght@400;600;700;800;900&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Nunito', sans-serif !important; }
  ::-webkit-scrollbar { width: 5px; height: 5px; }
  ::-webkit-scrollbar-thumb { background: #E84B1E55; border-radius: 99px; }

  .pac { font-family: 'Pacifico', cursive !important; }

  .btn-hot {
    background: linear-gradient(135deg, #E84B1E 0%, #FF6B35 100%);
    color: white; border: none; border-radius: 14px;
    padding: 13px 28px; font-family: 'Nunito', sans-serif; font-weight: 800;
    cursor: pointer; transition: all .2s; font-size: 15px; display: inline-flex; align-items: center; justify-content: center; gap: 7px;
  }
  .btn-hot:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(232,75,30,.38); }
  .btn-hot:active { transform: translateY(0); }
  .btn-hot:disabled { opacity: .65; cursor: not-allowed; transform: none; }

  .btn-out {
    background: white; color: #E84B1E; border: 2.5px solid #E84B1E;
    border-radius: 14px; padding: 11px 26px; font-family: 'Nunito', sans-serif;
    font-weight: 800; cursor: pointer; transition: all .2s; font-size: 15px; display: inline-flex; align-items: center; justify-content: center; gap: 7px;
  }
  .btn-out:hover { background: #FFF0EC; }
  .btn-out:disabled { opacity: .65; cursor: not-allowed; }

  .btn-green {
    background: #25D366; color: white; border: none; border-radius: 14px;
    padding: 10px 20px; font-family: 'Nunito', sans-serif; font-weight: 800;
    cursor: pointer; font-size: 14px; display: inline-flex; align-items: center; justify-content: center; gap: 7px;
  }

  .card { background: white; border-radius: 20px; box-shadow: 0 4px 24px rgba(0,0,0,.07); overflow: hidden; }
  .card-inner { background: white; border-radius: 20px; box-shadow: 0 4px 24px rgba(0,0,0,.07); }

  .inp {
    width: 100%; padding: 12px 15px; border: 2.5px solid #FFE5D5;
    border-radius: 12px; font-family: 'Nunito', sans-serif; font-size: 14px;
    outline: none; transition: border .2s; background: #FFFAF8; color: #1A0A00;
  }
  .inp:focus { border-color: #E84B1E; }
  .inp::placeholder { color: #C8A090; }

  .tab-btn {
    background: transparent; border: none; cursor: pointer;
    font-family: 'Nunito', sans-serif; font-weight: 700;
    padding: 11px 14px; color: #AAA; border-bottom: 3px solid transparent;
    transition: all .2s; font-size: 14px; white-space: nowrap;
  }
  .tab-btn.on { color: #E84B1E; border-bottom-color: #E84B1E; }
  .tab-btn:hover { color: #E84B1E; }

  @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
  .fu { animation: fadeUp .35s ease both; }
  @keyframes pop { 0%{transform:scale(.85)} 65%{transform:scale(1.06)} 100%{transform:scale(1)} }
  .pop { animation: pop .35s ease both; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.55} }
  .pulse { animation: pulse 1.8s ease infinite; }

  .chip {
    padding: 5px 14px; border-radius: 99px; border: 2px solid;
    font-family: 'Nunito', sans-serif; font-weight: 700; cursor: pointer;
    font-size: 13px; transition: all .15s;
  }
`;

/* ════════════════════════════════════════════
   ROOT APP
════════════════════════════════════════════ */
export default function App() {
  const [view, setView]     = useState('menu');
  const [user, setUser]     = useState(null);
  const [isAdmin, setAdmin] = useState(false);
  const [cart, setCart]     = useState([]);
  const [cfg, setCfg]       = useState(DEF_CONFIG);
  const [menu, setMenu]     = useState({ ...DEF_MENU, date: nowDate() });
  const [antos, setAntos]   = useState([]);
  const [orders, setOrders] = useState([]);
  const [users, setUsers]   = useState([]);
  const [toast, setToast]   = useState(null);
  const [ready, setReady]   = useState(false);

  const notify = (msg, err = false) => {
    setToast({ msg, err });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    (async () => {
      const [c, m, a, o, u, s] = await Promise.all([
        db.get('cfg'), db.get('menu'), db.get('antos'),
        db.get('orders'), db.get('users'), db.get('sess')
      ]);
      if (c) setCfg(c);
      if (m) setMenu(m);
      if (a) setAntos(a);
      if (o) setOrders(o);
      if (u) setUsers(u);
      if (s?.admin) { setAdmin(true); setView('admin'); }
      else if (s?.user) setUser(s.user);
      setReady(true);
    })();
  }, []);

  const saveCfg    = async v => { setCfg(v);    await db.set('cfg', v); };
  const saveMenu   = async v => { setMenu(v);   await db.set('menu', v); };
  const saveAntos  = async v => { setAntos(v);  await db.set('antos', v); };
  const saveOrders = async v => { setOrders(v); await db.set('orders', v); };
  const saveUsers  = async v => { setUsers(v);  await db.set('users', v); };

  const loginAdmin = async (u, p) => {
    if (u === 'admin' && p === 'comedor2024') {
      setAdmin(true); setView('admin');
      await db.set('sess', { admin: true }); return true;
    }
    return false;
  };
  const loginUser = async (usuario, clave) => {
    const u = users.find(x => x.usuario === usuario && x.clave === clave);
    if (u) { setUser(u); setView('menu'); await db.set('sess', { user: u }); return true; }
    return false;
  };
  const registerUser = async (data) => {
    if (users.find(x => x.usuario === data.usuario)) return 'usuario';
    if (users.find(x => x.email === data.email)) return 'email';
    const u = { ...data, id: uid(), role: 'customer' };
    await saveUsers([...users, u]);
    setUser(u); await db.set('sess', { user: u }); return 'ok';
  };
  const logout = async () => {
    setUser(null); setAdmin(false); setView('menu'); setCart([]);
    await db.set('sess', null);
  };
  const placeOrder = async (data) => {
    const o = { ...data, id: uid(), status: 'pendiente', createdAt: new Date().toISOString(), userId: user?.id, userName: user?.nombre };
    const arr = [o, ...orders]; await saveOrders(arr); return o;
  };
  const updateStatus = async (id, status) => {
    const arr = orders.map(o => o.id === id ? { ...o, status } : o);
    await saveOrders(arr);
  };

  const ctx = {
    view, setView, user, isAdmin, cart, setCart, cfg, menu, antos, orders, users,
    notify, loginAdmin, loginUser, registerUser, logout, placeOrder, updateStatus,
    saveCfg, saveMenu, saveAntos, saveOrders
  };

  if (!ready) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#FFF8F0' }}>
      <style>{GLOBAL_CSS}</style>
      <div style={{ textAlign: 'center' }}>
        <div className="pulse" style={{ fontSize: 64 }}>🍽️</div>
        <p className="pac" style={{ color: '#E84B1E', fontSize: 22, marginTop: 12 }}>Cargando...</p>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: '#FFF8F0', fontFamily: "'Nunito', sans-serif" }}>
      <style>{GLOBAL_CSS}</style>
      <NavBar {...ctx} />
      <main style={{ maxWidth: 880, margin: '0 auto', padding: '20px 14px 100px' }}>
        {view === 'menu'        && <MenuPage      {...ctx} />}
        {view === 'login'       && <LoginPage     {...ctx} />}
        {view === 'register'    && <RegisterPage  {...ctx} />}
        {view === 'order'       && <OrderPage     {...ctx} />}
        {view === 'admin-login' && <AdminLogin    {...ctx} />}
        {view === 'admin' && isAdmin && <AdminPanel {...ctx} />}
        {view === 'my-orders' && user && <MyOrders  {...ctx} />}
      </main>
      {toast && (
        <div className="fu" style={{
          position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
          background: toast.err ? '#C0392B' : '#1E6B2D',
          color: 'white', padding: '12px 24px', borderRadius: 16, fontWeight: 800,
          zIndex: 9999, boxShadow: '0 8px 32px rgba(0,0,0,.25)', fontSize: 14, whiteSpace: 'nowrap'
        }}>
          {toast.err ? '❌' : '✅'} {toast.msg}
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════
   NAV BAR
════════════════════════════════════════════ */
function NavBar({ setView, user, isAdmin, cart, logout, cfg }) {
  const count = cart.reduce((s, i) => s + i.qty, 0);
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  return (
    <header style={{ background: 'white', boxShadow: '0 2px 20px rgba(0,0,0,.08)', position: 'sticky', top: 0, zIndex: 200 }}>
      <div style={{ maxWidth: 880, margin: '0 auto', padding: '0 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
        <div onClick={() => setView('menu')} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', textDecoration: 'none' }}>
          {cfg.logo
            ? <img src={cfg.logo} alt="" style={{ width: 44, height: 44, borderRadius: '50%', objectFit: 'cover', border: '2px solid #FFE5D5' }} />
            : <div style={{ width: 44, height: 44, background: 'linear-gradient(135deg,#E84B1E,#F5A623)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🍽️</div>
          }
          <span className="pac" style={{ fontSize: 20, color: '#E84B1E', lineHeight: 1 }}>{cfg.name}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {!isAdmin && (
            <button onClick={() => setView('order')} style={{
              position: 'relative', background: count > 0 ? 'linear-gradient(135deg,#E84B1E,#FF6B35)' : '#F5F5F5',
              border: 'none', borderRadius: 99, height: 42, padding: '0 14px', cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 6, transition: 'all .2s'
            }}>
              <ShoppingCart size={18} color={count > 0 ? 'white' : '#AAA'} />
              {count > 0 && <>
                <span style={{ color: 'white', fontWeight: 800, fontSize: 13 }}>{fmt$(total)}</span>
                <span style={{ position: 'absolute', top: -4, right: -4, background: '#2D5016', color: 'white', width: 20, height: 20, borderRadius: '50%', fontSize: 11, fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{count}</span>
              </>}
            </button>
          )}
          {user && !isAdmin && (
            <>
              <button onClick={() => setView('my-orders')} className="btn-out" style={{ padding: '7px 13px', fontSize: 13 }}>Mis Pedidos</button>
              <button onClick={logout} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#CCC', padding: 4 }}><LogOut size={17} /></button>
            </>
          )}
          {isAdmin && <button onClick={logout} className="btn-out" style={{ padding: '7px 13px', fontSize: 13 }}><LogOut size={14} />Salir</button>}
          {!user && !isAdmin && <button onClick={() => setView('login')} className="btn-hot" style={{ padding: '8px 18px', fontSize: 14 }}>Ingresar</button>}
          <button onClick={() => setView('admin-login')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#DDD', padding: '4px' }} title="Administrador">
            <Settings size={15} />
          </button>
        </div>
      </div>
    </header>
  );
}

/* ════════════════════════════════════════════
   MENU PAGE
════════════════════════════════════════════ */
function MenuPage({ menu, antos, cart, setCart, cfg, setView, user, notify }) {
  const addToCart = (item) => {
    const ex = cart.find(c => c.id === item.id);
    if (ex) setCart(cart.map(c => c.id === item.id ? { ...c, qty: c.qty + 1 } : c));
    else setCart([...cart, { ...item, qty: 1 }]);
    notify(item.name + ' agregado al carrito 🛒');
  };
  const decCart = (item) => {
    const ex = cart.find(c => c.id === item.id);
    if (!ex) return;
    if (ex.qty === 1) setCart(cart.filter(c => c.id !== item.id));
    else setCart(cart.map(c => c.id === item.id ? { ...c, qty: c.qty - 1 } : c));
  };
  const qty = (id) => cart.find(c => c.id === id)?.qty || 0;

  const grouped = {};
  (menu.items || []).forEach(i => { if (!grouped[i.cat]) grouped[i.cat] = []; grouped[i.cat].push(i); });
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);

  return (
    <div>
      {/* Hero */}
      <div className="fu card" style={{
        background: 'linear-gradient(135deg,#E84B1E 0%,#FF6B35 55%,#F5A623 100%)',
        padding: '30px 24px', marginBottom: 24, color: 'white', textAlign: 'center',
        position: 'relative', overflow: 'hidden', borderRadius: 24
      }}>
        <div style={{ position: 'absolute', fontSize: 120, opacity: .06, top: -20, right: -20, lineHeight: 1, userSelect: 'none' }}>🍽️</div>
        <div style={{ position: 'absolute', fontSize: 80, opacity: .06, bottom: -10, left: 10, lineHeight: 1, userSelect: 'none' }}>✨</div>
        {cfg.logo && <img src={cfg.logo} alt="" style={{ width: 64, height: 64, borderRadius: '50%', objectFit: 'cover', border: '3px solid rgba(255,255,255,.5)', marginBottom: 8 }} />}
        <p className="pac" style={{ fontSize: 28, marginBottom: 4, textShadow: '0 2px 8px rgba(0,0,0,.15)' }}>
          {menu.active ? '¡Menú de Hoy! 😋' : `¡Bienvenido a ${cfg.name}!`}
        </p>
        <p style={{ opacity: .85, fontSize: 13, marginBottom: 10, textTransform: 'capitalize' }}>{menu.date || nowDate()}</p>
        {menu.active && (
          <span style={{ background: 'rgba(255,255,255,.2)', backdropFilter: 'blur(4px)', padding: '6px 20px', borderRadius: 99, fontSize: 13 }}>
            {menu.message}
          </span>
        )}
        {!user && (
          <div style={{ marginTop: 18, display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button onClick={() => setView('register')} style={{ background: 'white', color: '#E84B1E', border: 'none', borderRadius: 99, padding: '9px 22px', fontFamily: "'Nunito',sans-serif", fontWeight: 800, cursor: 'pointer', fontSize: 14 }}>
              Crear Cuenta
            </button>
            <button onClick={() => setView('login')} style={{ background: 'transparent', color: 'white', border: '2px solid white', borderRadius: 99, padding: '7px 20px', fontFamily: "'Nunito',sans-serif", fontWeight: 700, cursor: 'pointer', fontSize: 14 }}>
              Ingresar
            </button>
          </div>
        )}
        {user && (
          <div style={{ marginTop: 12, background: 'rgba(255,255,255,.2)', borderRadius: 99, display: 'inline-block', padding: '5px 16px', fontSize: 13 }}>
            👋 Hola, <strong>{user.nombre.split(' ')[0]}</strong>
          </div>
        )}
      </div>

      {/* Daily Menu */}
      {menu.active && (menu.items || []).length > 0 ? (
        <div className="fu">
          <h2 className="pac" style={{ color: '#E84B1E', fontSize: 22, marginBottom: 16 }}>🗣️ Menú del Día</h2>
          {Object.entries(grouped).map(([cat, items]) => (
            <div key={cat} style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 11, fontWeight: 900, textTransform: 'uppercase', letterSpacing: 1.4, color: '#C08060', marginBottom: 8, paddingLeft: 4 }}>
                {CAT_LABELS[cat] || cat}
              </div>
              {items.map(item => (
                <div key={item.id} className="card" style={{ padding: '13px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8, transition: 'box-shadow .2s' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span style={{ fontSize: 28, lineHeight: 1 }}>{item.emoji || '🍴'}</span>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 15, color: '#1A0A00' }}>{item.name}</div>
                      {item.price > 0
                        ? <div style={{ color: '#E84B1E', fontWeight: 900, fontSize: 15 }}>{fmt$(item.price)}</div>
                        : <div style={{ color: '#2D5016', fontSize: 12, fontWeight: 700 }}>Incluida ✓</div>
                      }
                    </div>
                  </div>
                  {item.price > 0 && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      {qty(item.id) > 0 && (
                        <>
                          <button onClick={() => decCart(item)} style={{ width: 30, height: 30, borderRadius: '50%', border: '2px solid #E84B1E', background: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#E84B1E', transition: 'all .15s' }}>
                            <Minus size={13} />
                          </button>
                          <span style={{ fontWeight: 900, minWidth: 20, textAlign: 'center', fontSize: 15, color: '#1A0A00' }}>{qty(item.id)}</span>
                        </>
                      )}
                      <button onClick={() => addToCart(item)} style={{ width: 30, height: 30, borderRadius: '50%', background: 'linear-gradient(135deg,#E84B1E,#FF6B35)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all .15s' }}>
                        <Plus size={14} color="white" />
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      ) : (
        <div className="card fu" style={{ padding: 44, textAlign: 'center' }}>
          <div style={{ fontSize: 60, marginBottom: 8 }}>🍽️</div>
          <p className="pac" style={{ color: '#E84B1E', fontSize: 20 }}>Menú en Preparación</p>
          <p style={{ color: '#AAA', marginTop: 8, fontSize: 14 }}>El menú de hoy estará disponible muy pronto</p>
          <p style={{ color: '#E84B1E', fontWeight: 800, marginTop: 10 }}>📞 {cfg.phone}</p>
        </div>
      )}

      {/* Antojitos Section */}
      {(antos || []).filter(a => a.active !== false).length > 0 && (
        <div style={{ marginTop: 32 }} className="fu">
          <h2 className="pac" style={{ color: '#F5A623', fontSize: 22, marginBottom: 4 }}>🌟 Antojitos de la Tarde</h2>
          <p style={{ color: '#AAA', fontSize: 13, marginBottom: 16 }}>Delicias disponibles por la tarde</p>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(255px, 1fr))', gap: 14 }}>
            {(antos || []).filter(a => a.active !== false).map(a => (
              <div key={a.id} className="card" style={{ transition: 'transform .2s, box-shadow .2s' }}>
                {a.image
                  ? <img src={a.image} alt={a.title} style={{ width: '100%', height: 170, objectFit: 'cover' }} />
                  : <div style={{ height: 90, background: 'linear-gradient(135deg,#F5A623,#E84B1E)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40 }}>🌟</div>
                }
                <div style={{ padding: 14 }}>
                  <h3 style={{ fontWeight: 800, fontSize: 15, marginBottom: 4, color: '#1A0A00' }}>{a.title}</h3>
                  {a.desc && <p style={{ color: '#AAA', fontSize: 13, marginBottom: 8 }}>{a.desc}</p>}
                  {(a.items || []).map((it, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderBottom: '1px dashed #FFE5D5', fontSize: 14 }}>
                      <span style={{ color: '#555' }}>{it.name}</span>
                      <span style={{ color: '#E84B1E', fontWeight: 800 }}>{fmt$(it.price)}</span>
                    </div>
                  ))}
                  {(a.items || []).length > 0 && (
                    <button onClick={() => {
                      const it = a.items[0];
                      addToCart({ id: 'anto-' + a.id, name: a.title + (a.items.length > 1 ? ' - ' + it.name : ''), price: parseFloat(it.price) || 0, emoji: '🌟', cat: 'antojito' });
                    }} className="btn-hot" style={{ width: '100%', marginTop: 12, padding: '10px', fontSize: 14 }}>
                      Agregar al Pedido
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Floating Cart */}
      {cartCount > 0 && (
        <div style={{ position: 'fixed', bottom: 20, left: '50%', transform: 'translateX(-50%)', zIndex: 150, width: 'calc(100% - 28px)', maxWidth: 500 }}>
          <button onClick={() => user ? setView('order') : setView('login')} className="btn-hot" style={{
            width: '100%', padding: '15px 20px', fontSize: 15,
            boxShadow: '0 8px 32px rgba(232,75,30,.45)'
          }}>
            <ShoppingCart size={19} />
            Ver Pedido ({cartCount} items) — {fmt$(cartTotal)}
            <ChevronRight size={18} />
          </button>
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════
   LOGIN PAGE
════════════════════════════════════════════ */
function LoginPage({ loginUser, setView, notify }) {
  const [f, setF] = useState({ usuario: '', clave: '' });
  const [show, setShow] = useState(false);
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);
  const submit = async () => {
    if (!f.usuario || !f.clave) { setErr('Completa todos los campos'); return; }
    setLoading(true); setErr('');
    const ok = await loginUser(f.usuario, f.clave);
    setLoading(false);
    if (ok) notify('¡Bienvenido de vuelta! 👋');
    else setErr('Usuario o contraseña incorrectos');
  };
  return (
    <div className="fu" style={{ maxWidth: 400, margin: '0 auto', paddingTop: 16 }}>
      <div className="card" style={{ padding: 28 }}>
        <div style={{ textAlign: 'center', marginBottom: 22 }}>
          <div style={{ fontSize: 52, marginBottom: 4 }}>🔑</div>
          <h2 className="pac" style={{ color: '#E84B1E', fontSize: 22 }}>Iniciar Sesión</h2>
          <p style={{ color: '#AAA', fontSize: 14, marginTop: 4 }}>¡Bienvenido de vuelta!</p>
        </div>
        {err && <div style={{ background: '#FFF0ED', border: '1.5px solid #FFCABC', borderRadius: 10, padding: '9px 13px', color: '#C0392B', fontSize: 14, marginBottom: 14, fontWeight: 700 }}>⚠️ {err}</div>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
          <input className="inp" placeholder="Usuario" value={f.usuario} onChange={e => setF({ ...f, usuario: e.target.value })} onKeyDown={e => e.key === 'Enter' && submit()} />
          <div style={{ position: 'relative' }}>
            <input className="inp" type={show ? 'text' : 'password'} placeholder="Contraseña" value={f.clave} onChange={e => setF({ ...f, clave: e.target.value })} style={{ paddingRight: 46 }} onKeyDown={e => e.key === 'Enter' && submit()} />
            <button onClick={() => setShow(s => !s)} style={{ position: 'absolute', right: 13, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#C08060' }}>
              {show ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
          <button className="btn-hot" onClick={submit} disabled={loading} style={{ width: '100%', padding: '13px' }}>
            {loading ? 'Ingresando...' : 'Ingresar 🔑'}
          </button>
        </div>
        <p style={{ textAlign: 'center', marginTop: 16, fontSize: 14, color: '#AAA' }}>
          ¿No tienes cuenta?{' '}
          <span onClick={() => setView('register')} style={{ color: '#E84B1E', fontWeight: 800, cursor: 'pointer' }}>Regístrate aquí</span>
        </p>
        <p style={{ textAlign: 'center', marginTop: 8 }}>
          <button onClick={() => setView('menu')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#CCC', fontSize: 13 }}>← Volver al menú</button>
        </p>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════
   REGISTER PAGE
════════════════════════════════════════════ */
function RegisterPage({ registerUser, setView, notify }) {
  const [f, setF] = useState({ nombre: '', telefono: '', email: '', direccion: '', usuario: '', clave: '' });
  const [show, setShow] = useState(false);
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);
  const up = k => e => setF(p => ({ ...p, [k]: e.target.value }));
  const submit = async () => {
    const missing = ['nombre', 'telefono', 'email', 'direccion', 'usuario', 'clave'].find(k => !f[k]?.trim());
    if (missing) { setErr('Completa todos los campos'); return; }
    if (f.clave.length < 6) { setErr('La contraseña debe tener al menos 6 caracteres'); return; }
    setLoading(true); setErr('');
    const res = await registerUser(f);
    setLoading(false);
    if (res === 'ok') { notify('¡Cuenta creada! Bienvenido 🎉'); setView('menu'); }
    else if (res === 'usuario') setErr('Ese nombre de usuario ya está en uso');
    else setErr('Ese correo ya está registrado');
  };
  return (
    <div className="fu" style={{ maxWidth: 460, margin: '0 auto', paddingTop: 12 }}>
      <div className="card" style={{ padding: 28 }}>
        <div style={{ textAlign: 'center', marginBottom: 20 }}>
          <div style={{ fontSize: 48, marginBottom: 4 }}>👋</div>
          <h2 className="pac" style={{ color: '#E84B1E', fontSize: 22 }}>Crear Cuenta</h2>
          <p style={{ color: '#AAA', fontSize: 14, marginTop: 4 }}>Regístrate para hacer tus pedidos fácilmente</p>
        </div>
        {err && <div style={{ background: '#FFF0ED', border: '1.5px solid #FFCABC', borderRadius: 10, padding: '9px 13px', color: '#C0392B', fontSize: 14, marginBottom: 14, fontWeight: 700 }}>⚠️ {err}</div>}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
          <input className="inp" placeholder="Nombre completo *" value={f.nombre} onChange={up('nombre')} style={{ gridColumn: '1/-1' }} />
          <input className="inp" placeholder="Teléfono *" value={f.telefono} onChange={up('telefono')} />
          <input className="inp" placeholder="Email *" type="email" value={f.email} onChange={up('email')} />
          <input className="inp" placeholder="Dirección de entrega *" value={f.direccion} onChange={up('direccion')} style={{ gridColumn: '1/-1' }} />
          <input className="inp" placeholder="Nombre de usuario *" value={f.usuario} onChange={up('usuario')} />
          <div style={{ position: 'relative' }}>
            <input className="inp" type={show ? 'text' : 'password'} placeholder="Contraseña *" value={f.clave} onChange={up('clave')} style={{ paddingRight: 44 }} onKeyDown={e => e.key === 'Enter' && submit()} />
            <button onClick={() => setShow(s => !s)} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#C08060' }}>
              {show ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>
        <button className="btn-hot" onClick={submit} disabled={loading} style={{ width: '100%', padding: '13px' }}>
          {loading ? 'Creando cuenta...' : 'Crear Cuenta 🎉'}
        </button>
        <p style={{ textAlign: 'center', marginTop: 14, fontSize: 14, color: '#AAA' }}>
          ¿Ya tienes cuenta?{' '}
          <span onClick={() => setView('login')} style={{ color: '#E84B1E', fontWeight: 800, cursor: 'pointer' }}>Inicia sesión</span>
        </p>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════
   ORDER PAGE
════════════════════════════════════════════ */
function OrderPage({ cart, setCart, user, cfg, placeOrder, setView, notify }) {
  const [time, setTime] = useState('');
  const [addr, setAddr] = useState(user?.direccion || '');
  const [notes, setNotes] = useState('');
  const [sent, setSent] = useState(null);
  const [loading, setLoading] = useState(false);

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const count = cart.reduce((s, i) => s + i.qty, 0);
  const remove = (id) => setCart(cart.filter(c => c.id !== id));
  const changeQty = (id, qty) => { if (qty < 1) remove(id); else setCart(cart.map(c => c.id === id ? { ...c, qty } : c)); };

  const checkout = async () => {
    if (!time) { notify('Selecciona un horario de entrega', true); return; }
    if (!addr.trim()) { notify('Ingresa la dirección de entrega', true); return; }
    if (cart.length === 0) { notify('El carrito está vacío', true); return; }
    setLoading(true);
    const o = await placeOrder({ items: cart, deliveryTime: time, address: addr, notes, total, phone: user.telefono, email: user.email });
    setCart([]); setSent(o); setLoading(false);
  };

  if (sent) return (
    <div className="fu" style={{ maxWidth: 460, margin: '0 auto', paddingTop: 16 }}>
      <div className="card" style={{ padding: 32, textAlign: 'center' }}>
        <div className="pop" style={{ fontSize: 72, marginBottom: 8 }}>🎉</div>
        <h2 className="pac" style={{ color: '#2D5016', fontSize: 24, marginBottom: 6 }}>¡Pedido Registrado!</h2>
        <p style={{ color: '#666', marginBottom: 4 }}>Tu pedido <strong style={{ color: '#E84B1E' }}>#{sent.id.slice(-6).toUpperCase()}</strong> fue recibido</p>
        <p style={{ fontWeight: 700, color: '#1A0A00', marginBottom: 20 }}>⏰ Entrega programada: <span style={{ color: '#E84B1E' }}>{sent.deliveryTime}</span></p>
        <div style={{ background: '#F8FFF9', border: '1.5px solid #C3E6CB', borderRadius: 14, padding: '12px 16px', marginBottom: 20, textAlign: 'left' }}>
          {(sent.items || []).map((it, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, padding: '3px 0' }}>
              <span>{it.emoji} {it.qty}x {it.name}</span>
              <span style={{ fontWeight: 800 }}>{fmt$(it.price * it.qty)}</span>
            </div>
          ))}
          <div style={{ borderTop: '1px dashed #C3E6CB', marginTop: 8, paddingTop: 8, display: 'flex', justifyContent: 'space-between', fontWeight: 900 }}>
            <span>Total</span><span style={{ color: '#E84B1E' }}>{fmt$(sent.total)}</span>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <a href={`https://wa.me/503${(cfg?.phone || '').replace(/\D/g, '')}?text=${encodeURIComponent(`Hola! Soy ${sent.userName}, hice un pedido #${sent.id.slice(-6).toUpperCase()} para las ${sent.deliveryTime}. Total: ${fmt$(sent.total)}`)}`} target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
            <button className="btn-green" style={{ width: '100%', padding: '13px' }}>📱 Confirmar por WhatsApp</button>
          </a>
          <button onClick={() => setView('my-orders')} className="btn-out" style={{ width: '100%' }}>Ver Mis Pedidos</button>
          <button onClick={() => setView('menu')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#E84B1E', fontWeight: 700, fontSize: 14 }}>← Volver al Menú</button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fu" style={{ maxWidth: 520, margin: '0 auto', paddingTop: 8 }}>
      <h2 className="pac" style={{ color: '#E84B1E', fontSize: 22, marginBottom: 16 }}>🛒 Tu Pedido</h2>
      {cart.length === 0 ? (
        <div className="card" style={{ padding: 44, textAlign: 'center' }}>
          <div style={{ fontSize: 54 }}>🛒</div>
          <p style={{ color: '#AAA', marginTop: 10, fontSize: 15 }}>Tu carrito está vacío</p>
          <button onClick={() => setView('menu')} className="btn-hot" style={{ marginTop: 18 }}>Ver Menú</button>
        </div>
      ) : (
        <>
          <div className="card" style={{ padding: 16, marginBottom: 14 }}>
            {cart.map(item => (
              <div key={item.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px dashed #FFE5D5' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, flex: 1, minWidth: 0 }}>
                  <span style={{ fontSize: 24, flexShrink: 0 }}>{item.emoji || '🍴'}</span>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.name}</div>
                    <div style={{ color: '#E84B1E', fontWeight: 900, fontSize: 14 }}>{fmt$(item.price)}</div>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, flexShrink: 0 }}>
                  <button onClick={() => changeQty(item.id, item.qty - 1)} style={{ width: 27, height: 27, borderRadius: '50%', border: '2px solid #E84B1E', background: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#E84B1E' }}>
                    <Minus size={12} />
                  </button>
                  <span style={{ fontWeight: 900, minWidth: 18, textAlign: 'center' }}>{item.qty}</span>
                  <button onClick={() => changeQty(item.id, item.qty + 1)} style={{ width: 27, height: 27, borderRadius: '50%', background: 'linear-gradient(135deg,#E84B1E,#FF6B35)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Plus size={12} color="white" />
                  </button>
                  <button onClick={() => remove(item.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#DDD', marginLeft: 2 }}>
                    <X size={16} />
                  </button>
                </div>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 12, fontWeight: 900, fontSize: 16 }}>
              <span>Total ({count} ítems)</span>
              <span style={{ color: '#E84B1E' }}>{fmt$(total)}</span>
            </div>
          </div>

          <div className="card" style={{ padding: 18, marginBottom: 14 }}>
            <h3 style={{ fontWeight: 800, marginBottom: 14, color: '#1A0A00', fontSize: 15 }}>📋 Datos de Entrega</h3>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 13, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 8 }}>⏰ Horario de Entrega *</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
                {DELIVERY_TIMES.map(t => (
                  <button key={t} onClick={() => setTime(t)} className="chip" style={{
                    borderColor: time === t ? '#E84B1E' : '#FFE5D5',
                    background: time === t ? '#E84B1E' : 'white',
                    color: time === t ? 'white' : '#888'
                  }}>{t}</button>
                ))}
              </div>
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 13, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 5 }}>📍 Dirección de Entrega *</label>
              <textarea className="inp" value={addr} onChange={e => setAddr(e.target.value)} placeholder="Colonia, calle, número de casa, referencias..." rows={2} style={{ resize: 'vertical' }} />
            </div>
            <div>
              <label style={{ fontSize: 13, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 5 }}>💬 Notas adicionales (opcional)</label>
              <input className="inp" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Instrucciones especiales, alérgenos, preferencias..." />
            </div>
          </div>

          <button className="btn-hot" onClick={checkout} disabled={loading} style={{ width: '100%', padding: '15px', fontSize: 16 }}>
            {loading ? 'Enviando pedido...' : '✅ Confirmar Pedido'}
          </button>
          <button onClick={() => setView('menu')} className="btn-out" style={{ width: '100%', marginTop: 10 }}>
            ← Seguir viendo el menú
          </button>
        </>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════
   ADMIN LOGIN
════════════════════════════════════════════ */
function AdminLogin({ loginAdmin, setView, notify }) {
  const [f, setF] = useState({ u: '', p: '' });
  const [err, setErr] = useState('');
  const [show, setShow] = useState(false);
  const submit = async () => {
    if (!f.u || !f.p) { setErr('Completa los campos'); return; }
    const ok = await loginAdmin(f.u, f.p);
    if (!ok) setErr('Credenciales incorrectas');
    else notify('Bienvenido, Administrador ⚙️');
  };
  return (
    <div className="fu" style={{ maxWidth: 360, margin: '0 auto', paddingTop: 20 }}>
      <div className="card" style={{ padding: 28 }}>
        <div style={{ textAlign: 'center', marginBottom: 20 }}>
          <div style={{ width: 64, height: 64, background: 'linear-gradient(135deg,#1A0A00,#3D1A00)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, margin: '0 auto 8px' }}>⚙️</div>
          <h2 className="pac" style={{ color: '#E84B1E', fontSize: 22 }}>Administrador</h2>
          <p style={{ color: '#AAA', fontSize: 13, marginTop: 4 }}>Panel de gestión del comedor</p>
        </div>
        {err && <div style={{ background: '#FFF0ED', border: '1.5px solid #FFCABC', borderRadius: 10, padding: '9px 13px', color: '#C0392B', fontSize: 14, marginBottom: 12, fontWeight: 700 }}>⚠️ {err}</div>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <input className="inp" placeholder="Usuario" value={f.u} onChange={e => setF(p => ({ ...p, u: e.target.value }))} />
          <div style={{ position: 'relative' }}>
            <input className="inp" type={show ? 'text' : 'password'} placeholder="Contraseña" value={f.p} onChange={e => setF(p => ({ ...p, p: e.target.value }))} style={{ paddingRight: 44 }} onKeyDown={e => e.key === 'Enter' && submit()} />
            <button onClick={() => setShow(s => !s)} style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#C08060' }}>
              {show ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          <button className="btn-hot" onClick={submit} style={{ width: '100%' }}>Ingresar al Panel</button>
        </div>
        <p style={{ textAlign: 'center', marginTop: 14 }}>
          <button onClick={() => setView('menu')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#E84B1E', fontWeight: 700, fontSize: 13 }}>← Volver al menú</button>
        </p>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════
   ADMIN PANEL
════════════════════════════════════════════ */
function AdminPanel(props) {
  const [tab, setTab] = useState('pedidos');
  const pending = (props.orders || []).filter(o => o.status === 'pendiente').length;
  const tabs = [
    ['pedidos', '📦 Pedidos', pending],
    ['menu', '🍽️ Menú', null],
    ['antojitos', '🌟 Antojitos', null],
    ['config', '⚙️ Config', null],
  ];
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
        <h2 className="pac" style={{ color: '#E84B1E', fontSize: 22 }}>Panel de Administración</h2>
        {pending > 0 && <span style={{ background: '#E84B1E', color: 'white', padding: '5px 14px', borderRadius: 99, fontSize: 13, fontWeight: 800 }}>🔔 {pending} nuevo{pending > 1 ? 's' : ''}</span>}
      </div>
      <div style={{ borderBottom: '2.5px solid #FFE5D5', marginBottom: 20, display: 'flex', gap: 2, overflowX: 'auto' }}>
        {tabs.map(([k, l, badge]) => (
          <button key={k} className={`tab-btn${tab === k ? ' on' : ''}`} onClick={() => setTab(k)} style={{ position: 'relative' }}>
            {l}
            {badge > 0 && <span style={{ position: 'absolute', top: 4, right: 2, background: '#E84B1E', color: 'white', width: 16, height: 16, borderRadius: '50%', fontSize: 10, fontWeight: 900, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{badge}</span>}
          </button>
        ))}
      </div>
      {tab === 'pedidos'   && <AdminOrders    {...props} />}
      {tab === 'menu'      && <AdminMenu      {...props} />}
      {tab === 'antojitos' && <AdminAntojitos {...props} />}
      {tab === 'config'    && <AdminConfig    {...props} />}
    </div>
  );
}

/* ─── Admin: Orders Dashboard ─── */
function AdminOrders({ orders, updateStatus, notify }) {
  const [filter, setFilter] = useState('todos');
  const [tick, setTick] = useState(0);
  useEffect(() => { const id = setInterval(() => setTick(t => t + 1), 30000); return () => clearInterval(id); }, []);

  const all = orders || [];
  const filtered = filter === 'todos' ? all : all.filter(o => o.status === filter);
  const stats = {
    total: all.length,
    pendiente: all.filter(o => o.status === 'pendiente').length,
    activos: all.filter(o => ['preparando', 'enviado'].includes(o.status)).length,
    ingresos: all.reduce((s, o) => s + (o.total || 0), 0)
  };

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))', gap: 10, marginBottom: 20 }}>
        {[
          { label: 'Total Pedidos', val: stats.total, c: '#E84B1E', e: '📦' },
          { label: 'Pendientes', val: stats.pendiente, c: '#856404', e: '⏳' },
          { label: 'En Proceso', val: stats.activos, c: '#0C5460', e: '🍳' },
          { label: 'Ingresos', val: fmt$(stats.ingresos), c: '#155724', e: '💵' },
        ].map((s, i) => (
          <div key={i} className="card" style={{ padding: '14px 10px', textAlign: 'center' }}>
            <div style={{ fontSize: 26 }}>{s.e}</div>
            <div style={{ fontWeight: 900, fontSize: 20, color: s.c, marginTop: 4, lineHeight: 1 }}>{s.val}</div>
            <div style={{ fontSize: 11, color: '#AAA', fontWeight: 700, marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 7, marginBottom: 16, flexWrap: 'wrap', alignItems: 'center' }}>
        {['todos', 'pendiente', 'preparando', 'enviado', 'entregado'].map(f => (
          <button key={f} onClick={() => setFilter(f)} className="chip" style={{
            borderColor: filter === f ? '#E84B1E' : '#FFE5D5',
            background: filter === f ? '#E84B1E' : 'white',
            color: filter === f ? 'white' : '#888'
          }}>
            {f === 'todos' ? 'Todos' : STATUS_INFO[f]?.label || f}
          </button>
        ))}
        <button onClick={() => setTick(t => t + 1)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#CCC', marginLeft: 'auto' }} title="Actualizar">
          <RefreshCw size={15} />
        </button>
      </div>

      {filtered.length === 0 ? (
        <div className="card" style={{ padding: 36, textAlign: 'center' }}>
          <div style={{ fontSize: 44 }}>📭</div>
          <p style={{ color: '#AAA', marginTop: 10 }}>No hay pedidos {filter !== 'todos' ? 'en este estado' : ''}</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[...filtered].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map(o => (
            <OrderCard key={o.id} order={o} updateStatus={updateStatus} notify={notify} />
          ))}
        </div>
      )}
    </div>
  );
}

function OrderCard({ order: o, updateStatus, notify }) {
  const [open, setOpen] = useState(false);
  const info = STATUS_INFO[o.status] || {};
  const next = STATUS_NEXT[o.status];
  const timeStr = new Date(o.createdAt).toLocaleString('es-SV', { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' });
  return (
    <div className="card" style={{ overflow: 'visible', border: o.status === 'pendiente' ? '1.5px solid #FFCABC' : 'none' }}>
      <div onClick={() => setOpen(v => !v)} style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'linear-gradient(135deg,#E84B1E,#F5A623)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 900, fontSize: 11, flexShrink: 0 }}>
            #{o.id.slice(-4).toUpperCase()}
          </div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 14 }}>{o.userName}</div>
            <div style={{ fontSize: 12, color: '#AAA' }}>⏰ {o.deliveryTime} · {timeStr}</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, flexShrink: 0 }}>
          <span style={{ fontWeight: 900, color: '#E84B1E', fontSize: 15 }}>{fmt$(o.total)}</span>
          <span style={{ background: info.bg, color: info.color, padding: '4px 11px', borderRadius: 99, fontSize: 12, fontWeight: 800 }}>{info.label}</span>
          <ChevronDown size={15} style={{ color: '#CCC', transform: open ? 'rotate(180deg)' : '', transition: 'transform .2s' }} />
        </div>
      </div>
      {open && (
        <div className="fu" style={{ borderTop: '1px solid #FFF0E8', padding: '14px 16px', background: '#FFFAF8' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 12, fontSize: 13 }}>
            <div style={{ color: '#555' }}><span style={{ color: '#AAA' }}>📍 </span>{o.address}</div>
            <div style={{ color: '#555' }}><span style={{ color: '#AAA' }}>📞 </span>{o.phone}</div>
            {o.email && <div style={{ color: '#555' }}><span style={{ color: '#AAA' }}>📧 </span>{o.email}</div>}
            {o.notes && <div style={{ gridColumn: '1/-1', color: '#555' }}><span style={{ color: '#AAA' }}>💬 </span>{o.notes}</div>}
          </div>
          <div style={{ background: 'white', borderRadius: 12, padding: '10px 12px', marginBottom: 12 }}>
            {(o.items || []).map((it, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', fontSize: 14 }}>
                <span>{it.emoji} {it.qty}x {it.name}</span>
                <span style={{ fontWeight: 800 }}>{fmt$(it.price * it.qty)}</span>
              </div>
            ))}
            <div style={{ borderTop: '1px dashed #FFE5D5', marginTop: 8, paddingTop: 8, display: 'flex', justifyContent: 'space-between', fontWeight: 900 }}>
              <span>Total</span><span style={{ color: '#E84B1E' }}>{fmt$(o.total)}</span>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {next && (
              <button className="btn-hot" style={{ padding: '9px 18px', fontSize: 13 }} onClick={async () => { await updateStatus(o.id, next); notify('Estado actualizado ✅'); }}>
                {STATUS_INFO[next]?.label} →
              </button>
            )}
            {o.email && (
              <a href={`mailto:${o.email}?subject=Tu pedido #${o.id.slice(-6).toUpperCase()} - ${info.label}&body=Hola ${o.userName}!%0A%0ATu pedido está: ${info.label}%0AEntrega: ${o.deliveryTime}%0ATotal: ${fmt$(o.total)}%0A%0A¡Gracias por tu pedido!`} style={{ textDecoration: 'none' }}>
                <button className="btn-out" style={{ padding: '9px 16px', fontSize: 13 }}><Mail size={14} />Email</button>
              </a>
            )}
            <a href={`https://wa.me/503${(o.phone || '').replace(/\D/g, '')}?text=${encodeURIComponent(`Hola ${o.userName}! 👋\nTu pedido #${o.id.slice(-6).toUpperCase()} está: ${info.label}\nEntrega: ${o.deliveryTime}\n¡Gracias!`)}`} target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
              <button className="btn-green" style={{ padding: '9px 16px', fontSize: 13 }}>📱 WhatsApp</button>
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Admin: Menu Editor ─── */
function AdminMenu({ menu, saveMenu, notify }) {
  const [m, setM] = useState({ ...menu, items: [...(menu.items || [])] });
  const [newItem, setNewItem] = useState({ cat: 'platos', name: '', emoji: '🍴', price: '' });
  const [saving, setSaving] = useState(false);

  const grouped = {};
  (m.items || []).forEach(i => { if (!grouped[i.cat]) grouped[i.cat] = []; grouped[i.cat].push(i); });

  const addItem = () => {
    if (!newItem.name || newItem.price === '') { notify('Nombre y precio son requeridos', true); return; }
    setM(prev => ({ ...prev, items: [...prev.items, { ...newItem, id: uid(), price: parseFloat(newItem.price) || 0 }] }));
    setNewItem(p => ({ ...p, name: '', price: '' }));
    notify('Ítem agregado ✅');
  };
  const removeItem = (id) => setM(prev => ({ ...prev, items: prev.items.filter(i => i.id !== id) }));
  const save = async () => { setSaving(true); await saveMenu(m); setSaving(false); notify('Menú guardado ✅'); };

  const mailBody = (m.items || []).map(i => `${i.emoji} ${i.name}${i.price > 0 ? ' ......... ' + fmt$(i.price) : ' (incluida)'}`).join('\n');
  const mailSubject = `Menú del Día - ${m.date}`;
  const mailContent = `🗣️ MENÚ DEL DÍA 😋\n\n${m.date}\n\n${mailBody}\n\n${m.message}`;

  return (
    <div>
      <div className="card" style={{ padding: 18, marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
          <div style={{ flex: 1, minWidth: 200 }}>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 5 }}>📅 Fecha del Menú</label>
            <input className="inp" value={m.date} onChange={e => setM(p => ({ ...p, date: e.target.value }))} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: m.active ? '#2D5016' : '#AAA' }}>
              {m.active ? '✅ Activo' : '⭕ Inactivo'}
            </span>
            <button onClick={() => setM(p => ({ ...p, active: !p.active }))} style={{ background: m.active ? '#2D5016' : '#999', border: 'none', borderRadius: 99, padding: '8px 18px', color: 'white', fontFamily: "'Nunito',sans-serif", fontWeight: 700, cursor: 'pointer', fontSize: 13 }}>
              {m.active ? 'Desactivar' : 'Activar'}
            </button>
          </div>
        </div>
        <label style={{ fontSize: 12, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 5 }}>💬 Mensaje del día</label>
        <input className="inp" value={m.message} onChange={e => setM(p => ({ ...p, message: e.target.value }))} placeholder="¡LINDO DÍA BENDICIONES! 🌈" />
      </div>

      {Object.entries(grouped).map(([cat, items]) => (
        <div key={cat} style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, fontWeight: 900, textTransform: 'uppercase', letterSpacing: 1.3, color: '#C08060', marginBottom: 8 }}>{CAT_LABELS[cat] || cat}</div>
          {items.map(it => (
            <div key={it.id} className="card" style={{ padding: '11px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 7 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 24 }}>{it.emoji}</span>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{it.name}</div>
                  <div style={{ color: '#E84B1E', fontWeight: 800, fontSize: 13 }}>{it.price > 0 ? fmt$(it.price) : 'Incluida'}</div>
                </div>
              </div>
              <button onClick={() => removeItem(it.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#FFBDAD', padding: 6 }}>
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      ))}

      <div className="card" style={{ padding: 16, marginBottom: 14, border: '2px dashed #FFE5D5' }}>
        <p style={{ fontSize: 13, fontWeight: 800, color: '#C08060', marginBottom: 11 }}>➕ Agregar Ítem al Menú</p>
        <div style={{ display: 'grid', gridTemplateColumns: '110px 1fr 52px 80px', gap: 8, marginBottom: 10 }}>
          <select className="inp" value={newItem.cat} onChange={e => setNewItem(p => ({ ...p, cat: e.target.value }))}>
            {['platos', 'extras', 'ensaladas', 'bebidas', 'postres'].map(c => <option key={c} value={c}>{CAT_LABELS[c]?.split(' ').slice(1).join(' ') || c}</option>)}
          </select>
          <input className="inp" placeholder="Nombre del ítem" value={newItem.name} onChange={e => setNewItem(p => ({ ...p, name: e.target.value }))} onKeyDown={e => e.key === 'Enter' && addItem()} />
          <select className="inp" value={newItem.emoji} onChange={e => setNewItem(p => ({ ...p, emoji: e.target.value }))} style={{ textAlign: 'center' }}>
            {FOOD_EMOJIS.map(e => <option key={e} value={e}>{e}</option>)}
          </select>
          <input className="inp" placeholder="$0.00" type="number" step="0.05" min="0" value={newItem.price} onChange={e => setNewItem(p => ({ ...p, price: e.target.value }))} />
        </div>
        <button onClick={addItem} className="btn-out" style={{ width: '100%', padding: '10px' }}>+ Agregar al Menú</button>
      </div>

      <button onClick={save} disabled={saving} className="btn-hot" style={{ width: '100%', padding: '14px', fontSize: 16, marginBottom: 10 }}>
        {saving ? 'Guardando...' : '💾 Guardar Menú'}
      </button>
      <a href={`mailto:?subject=${encodeURIComponent(mailSubject)}&body=${encodeURIComponent(mailContent)}`} style={{ textDecoration: 'none', display: 'block' }}>
        <button className="btn-out" style={{ width: '100%' }}><Mail size={16} />Enviar Menú por Email</button>
      </a>
    </div>
  );
}

/* ─── Admin: Antojitos Editor ─── */
function AdminAntojitos({ antos, saveAntos, notify }) {
  const [list, setList] = useState([...(antos || [])]);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ title: '', desc: '', image: null, items: [{ name: '', price: '' }] });
  const imgRef = useRef();

  const handleImg = (e) => {
    const file = e.target.files[0]; if (!file) return;
    if (file.size > 2 * 1024 * 1024) { notify('Imagen muy grande. Máximo 2MB', true); return; }
    const r = new FileReader();
    r.onload = ev => setForm(p => ({ ...p, image: ev.target.result }));
    r.readAsDataURL(file);
  };

  const toggle = async (id) => {
    const updated = list.map(a => a.id === id ? { ...a, active: !a.active } : a);
    setList(updated); await saveAntos(updated);
  };
  const del = async (id) => {
    const updated = list.filter(a => a.id !== id);
    setList(updated); await saveAntos(updated);
    notify('Antojito eliminado');
  };
  const save = async () => {
    if (!form.title.trim()) { notify('El título es requerido', true); return; }
    const anto = { ...form, id: uid(), active: true, items: form.items.filter(i => i.name && i.price) };
    const updated = [...list, anto];
    setList(updated); await saveAntos(updated);
    setForm({ title: '', desc: '', image: null, items: [{ name: '', price: '' }] });
    setAdding(false);
    notify('Antojito agregado ✅');
  };

  return (
    <div>
      {list.length === 0 && !adding && (
        <div className="card" style={{ padding: 36, textAlign: 'center', marginBottom: 16 }}>
          <div style={{ fontSize: 52 }}>🌟</div>
          <p style={{ color: '#AAA', marginTop: 10 }}>No hay antojitos cargados aún</p>
          <p style={{ color: '#C08060', fontSize: 13, marginTop: 6 }}>Agrega fotos con el menú de antojitos</p>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12, marginBottom: 16 }}>
        {list.map(a => (
          <div key={a.id} className="card" style={{ opacity: a.active !== false ? 1 : .5, transition: 'opacity .2s' }}>
            {a.image
              ? <img src={a.image} alt={a.title} style={{ width: '100%', height: 150, objectFit: 'cover' }} />
              : <div style={{ height: 80, background: 'linear-gradient(135deg,#F5A623,#E84B1E)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32 }}>🌟</div>
            }
            <div style={{ padding: 12 }}>
              <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 4 }}>{a.title}</div>
              {(a.items || []).map((it, i) => (
                <div key={i} style={{ fontSize: 13, color: '#888', lineHeight: 1.6 }}>{it.name} — <span style={{ color: '#E84B1E', fontWeight: 700 }}>{fmt$(it.price)}</span></div>
              ))}
              <div style={{ display: 'flex', gap: 7, marginTop: 10 }}>
                <button onClick={() => toggle(a.id)} style={{ flex: 1, padding: '7px 4px', borderRadius: 10, border: 'none', background: a.active !== false ? '#D4EDDA' : '#FFE5D5', color: a.active !== false ? '#155724' : '#C08060', fontFamily: "'Nunito',sans-serif", fontWeight: 700, cursor: 'pointer', fontSize: 12 }}>
                  {a.active !== false ? '✅ Activo' : '⭕ Inactivo'}
                </button>
                <button onClick={() => del(a.id)} style={{ padding: '7px 10px', borderRadius: 10, border: 'none', background: '#FFF0ED', color: '#E84B1E', cursor: 'pointer' }}>
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {adding ? (
        <div className="card" style={{ padding: 18 }}>
          <h3 style={{ fontWeight: 800, color: '#E84B1E', marginBottom: 14 }}>Nuevo Antojito</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <input className="inp" placeholder="Título (ej: Ricas Empanadas de Leche)" value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} />
            <input className="inp" placeholder="Descripción corta (opcional)" value={form.desc} onChange={e => setForm(p => ({ ...p, desc: e.target.value }))} />
            <div>
              <input type="file" accept="image/*" ref={imgRef} onChange={handleImg} style={{ display: 'none' }} />
              <button onClick={() => imgRef.current.click()} className="btn-out" style={{ width: '100%', padding: '11px', fontSize: 14 }}>
                <Upload size={15} />{form.image ? '✅ Imagen cargada — cambiar' : 'Cargar Imagen del Antojito'}
              </button>
              {form.image && <img src={form.image} alt="" style={{ width: '100%', maxHeight: 180, objectFit: 'cover', borderRadius: 12, marginTop: 8 }} />}
            </div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#AAA', marginBottom: 8 }}>Opciones / Precios</div>
              {form.items.map((it, i) => (
                <div key={i} style={{ display: 'flex', gap: 7, marginBottom: 7 }}>
                  <input className="inp" placeholder="Nombre de opción" value={it.name} onChange={e => setForm(p => ({ ...p, items: p.items.map((x, xi) => xi === i ? { ...x, name: e.target.value } : x) }))} />
                  <input className="inp" placeholder="Precio" type="number" step="0.05" min="0" value={it.price} onChange={e => setForm(p => ({ ...p, items: p.items.map((x, xi) => xi === i ? { ...x, price: e.target.value } : x) }))} style={{ width: 90 }} />
                  {form.items.length > 1 && <button onClick={() => setForm(p => ({ ...p, items: p.items.filter((_, xi) => xi !== i) }))} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#FFBDAD' }}><X size={16} /></button>}
                </div>
              ))}
              <button onClick={() => setForm(p => ({ ...p, items: [...p.items, { name: '', price: '' }] }))} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#E84B1E', fontWeight: 700, fontSize: 13 }}>+ Agregar opción</button>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn-hot" onClick={save} style={{ flex: 1 }}>Guardar Antojito</button>
              <button className="btn-out" onClick={() => setAdding(false)} style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      ) : (
        <button className="btn-hot" onClick={() => setAdding(true)} style={{ width: '100%', padding: '14px', fontSize: 15 }}>
          <Plus size={18} />Agregar Antojito
        </button>
      )}
    </div>
  );
}

/* ─── Admin: Config ─── */
function AdminConfig({ cfg, saveCfg, notify }) {
  const [c, setC] = useState({ ...cfg });
  const [saving, setSaving] = useState(false);
  const logoRef = useRef();

  const handleLogo = (e) => {
    const file = e.target.files[0]; if (!file) return;
    if (file.size > 1.5 * 1024 * 1024) { notify('Logo muy grande. Máximo 1.5MB', true); return; }
    const r = new FileReader();
    r.onload = ev => setC(p => ({ ...p, logo: ev.target.result }));
    r.readAsDataURL(file);
  };
  const save = async () => { setSaving(true); await saveCfg(c); setSaving(false); notify('Configuración guardada ✅'); };

  return (
    <div className="fu" style={{ maxWidth: 480 }}>
      <div className="card" style={{ padding: 20, marginBottom: 14 }}>
        <h3 style={{ fontWeight: 800, marginBottom: 16, color: '#E84B1E', fontSize: 15 }}>🏪 Datos del Comedor</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 7 }}>Logo del Comedor</label>
            <input type="file" accept="image/*" ref={logoRef} onChange={handleLogo} style={{ display: 'none' }} />
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              {c.logo
                ? <img src={c.logo} alt="" style={{ width: 64, height: 64, borderRadius: '50%', objectFit: 'cover', border: '3px solid #FFE5D5', flexShrink: 0 }} />
                : <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'linear-gradient(135deg,#E84B1E,#F5A623)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, flexShrink: 0 }}>🍽️</div>
              }
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => logoRef.current.click()} className="btn-out" style={{ padding: '8px 14px', fontSize: 13 }}>
                  <Upload size={13} />{c.logo ? 'Cambiar' : 'Subir Logo'}
                </button>
                {c.logo && <button onClick={() => setC(p => ({ ...p, logo: null }))} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#CCC' }}><X size={16} /></button>}
              </div>
            </div>
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 5 }}>Nombre del Comedor</label>
            <input className="inp" value={c.name} onChange={e => setC(p => ({ ...p, name: e.target.value }))} />
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 5 }}>📞 Teléfono / WhatsApp</label>
            <input className="inp" value={c.phone} onChange={e => setC(p => ({ ...p, phone: e.target.value }))} />
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 5 }}>📍 Dirección</label>
            <input className="inp" value={c.address} onChange={e => setC(p => ({ ...p, address: e.target.value }))} />
          </div>
          <div>
            <label style={{ fontSize: 12, fontWeight: 700, color: '#AAA', display: 'block', marginBottom: 5 }}>Descripción</label>
            <textarea className="inp" value={c.desc} onChange={e => setC(p => ({ ...p, desc: e.target.value }))} rows={3} style={{ resize: 'vertical' }} />
          </div>
        </div>
      </div>

      <div className="card" style={{ padding: 16, marginBottom: 14, background: '#FFFAF0', border: '1px solid #FFE5D5' }}>
        <h4 style={{ fontWeight: 800, fontSize: 14, color: '#C08060', marginBottom: 8 }}>🔐 Credenciales de Administrador</h4>
        <p style={{ fontSize: 13, color: '#888' }}>Usuario: <code style={{ background: '#FFE5D5', padding: '2px 6px', borderRadius: 6 }}>admin</code> · Contraseña: <code style={{ background: '#FFE5D5', padding: '2px 6px', borderRadius: 6 }}>comedor2024</code></p>
        <p style={{ fontSize: 12, color: '#E84B1E', marginTop: 6, fontWeight: 700 }}>⚠️ Cambia estas credenciales en el código fuente para mayor seguridad.</p>
      </div>

      <button onClick={save} disabled={saving} className="btn-hot" style={{ width: '100%', padding: '14px', fontSize: 16 }}>
        {saving ? 'Guardando...' : '💾 Guardar Configuración'}
      </button>
    </div>
  );
}

/* ════════════════════════════════════════════
   MY ORDERS (Customer)
════════════════════════════════════════════ */
function MyOrders({ orders, user, setView }) {
  const mine = (orders || []).filter(o => o.userId === user?.id);
  return (
    <div className="fu">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <h2 className="pac" style={{ color: '#E84B1E', fontSize: 22 }}>📦 Mis Pedidos</h2>
        <button onClick={() => setView('menu')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#E84B1E', fontWeight: 700, fontSize: 13 }}>← Volver</button>
      </div>
      {mine.length === 0 ? (
        <div className="card" style={{ padding: 44, textAlign: 'center' }}>
          <div style={{ fontSize: 54 }}>📭</div>
          <p style={{ color: '#AAA', marginTop: 10, fontSize: 15 }}>No tienes pedidos aún</p>
          <button onClick={() => setView('menu')} className="btn-hot" style={{ marginTop: 18 }}>Ver Menú del Día</button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[...mine].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map(o => {
            const info = STATUS_INFO[o.status] || {};
            return (
              <div key={o.id} className="card" style={{ padding: '14px 16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, alignItems: 'center' }}>
                  <span style={{ fontWeight: 800, color: '#E84B1E', fontSize: 14 }}>Pedido #{o.id.slice(-6).toUpperCase()}</span>
                  <span style={{ background: info.bg, color: info.color, padding: '4px 11px', borderRadius: 99, fontSize: 12, fontWeight: 800 }}>{info.label}</span>
                </div>
                <div style={{ fontSize: 13, color: '#AAA', marginBottom: 8 }}>⏰ {o.deliveryTime} · {new Date(o.createdAt).toLocaleDateString('es-SV')}</div>
                {(o.items || []).map((it, i) => (
                  <div key={i} style={{ fontSize: 14, color: '#555', padding: '2px 0', display: 'flex', justifyContent: 'space-between' }}>
                    <span>{it.emoji} {it.qty}x {it.name}</span>
                    <span style={{ fontWeight: 700 }}>{fmt$(it.price * it.qty)}</span>
                  </div>
                ))}
                <div style={{ borderTop: '1px dashed #FFE5D5', marginTop: 8, paddingTop: 8, display: 'flex', justifyContent: 'space-between', fontWeight: 900 }}>
                  <span style={{ color: '#888', fontSize: 14 }}>Total</span>
                  <span style={{ color: '#E84B1E', fontSize: 15 }}>{fmt$(o.total)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
